#include "Application.h"

int main()
{
    Application a;
    return 0;
}
